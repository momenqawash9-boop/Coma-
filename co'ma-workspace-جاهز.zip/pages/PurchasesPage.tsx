import React from 'react';

// PurchasesPage removed — functionality consolidated into ExpensesPage.
// This stub keeps imports referencing the path from breaking builds.
const PurchasesPage: React.FC = () => null;

export default PurchasesPage;
